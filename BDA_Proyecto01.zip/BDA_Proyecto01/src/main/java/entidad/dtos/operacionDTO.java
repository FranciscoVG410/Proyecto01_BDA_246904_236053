/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidad.dtos;

import java.util.Random;

/**
 *
 * @author franc
 */
public class operacionDTO {
    private int folio;
    private String contraseña;
    
    public operacionDTO() {
        folio = folioGenerado();
        contraseña = contraseñaGenerada();
    }

    private int folioGenerado() {
        Random rand = new Random();
        return rand.nextInt(99999);
    }

    private String contraseñaGenerada() {
        String caracteres = "0123456789";
        StringBuilder sb = new StringBuilder(8);
        Random aleatorio = new Random();
        for (int i = 0; i < 8; i++) {
            sb.append(caracteres.charAt(aleatorio.nextInt(caracteres.length())));
        }
        return sb.toString();
    }

    public int getFolio() {
        return folio;
    }

    public void setFolio(int folio) {
        this.folio = folio;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
}
