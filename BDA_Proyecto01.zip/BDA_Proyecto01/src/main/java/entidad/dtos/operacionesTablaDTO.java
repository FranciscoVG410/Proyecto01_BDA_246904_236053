/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidad.dtos;

import java.util.Date;


/**
 *
 * @author franc
 */
public class operacionesTablaDTO {
    private int folio;
    private boolean tipo;
    private float cantidad;
    private Date fechaHora;
    private boolean estado;
    private int cuentaReceptor;

    public operacionesTablaDTO() {
    }

    public operacionesTablaDTO(int folio, boolean tipo, float cantidad, Date fechaHora, boolean estado, int cuentaReceptor) {
        this.folio = folio;
        this.tipo = tipo;
        this.cantidad = cantidad;
        this.fechaHora = fechaHora;
        this.estado = estado;
        this.cuentaReceptor = cuentaReceptor;
    }

    public int getFolio() {
        return folio;
    }

    public void setFolio(int folio) {
        this.folio = folio;
    }

    public boolean isTipo() {
        return tipo;
    }

    public void setTipo(boolean tipo) {
        this.tipo = tipo;
    }

    public float getCantidad() {
        return cantidad;
    }

    public void setCantidad(float cantidad) {
        this.cantidad = cantidad;
    }

    public Date getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(Date fechaHora) {
        this.fechaHora = fechaHora;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = false;
    }

    public int getCuentaReceptor() {
        return cuentaReceptor;
    }

    public void setCuentaReceptor(int cuentaReceptor) {
        this.cuentaReceptor = cuentaReceptor;
    }
    
    
}
