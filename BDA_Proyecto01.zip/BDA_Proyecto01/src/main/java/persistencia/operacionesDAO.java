/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia;

import entidad.dtos.operacionesTablaDTO;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author franc
 */
public class operacionesDAO {

    private iConexionBD conexionBD;

    public operacionesDAO(iConexionBD conexionBD) {
        this.conexionBD = conexionBD;
    }
    public List<operacionesTablaDTO> buscarClientesTabla(int limit, int offset) throws OperacionRegistrosException {
        try {
            List<operacionesTablaDTO> operacionRegistros = null;

            Connection conectar = this.conexionBD.estableceConexion();
            String codigoSQL = "select t.*, tt.*, tr.estadoDeRetiro, tr.folio_transaccion transacciones t left join transaccion_transferencia tt ON t.folio = tt.folio_transaccion left join transaccion_retiro tr on t.folio = tr.folio_transaccion;"
                    + "LIMIT " + limit + " OFFSET " + offset + ";";
            Statement comandoSQL = conectar.createStatement();
            ResultSet resultado = comandoSQL.executeQuery(codigoSQL);
            while (resultado.next()) {
                if (operacionRegistros == null) {
                    operacionRegistros = new ArrayList<>();
                }
                operacionesTablaDTO operacion = this.operacionesTablaDTO(resultado);
                operacionRegistros.add(operacion);
            }
            conectar.close();
            return operacionRegistros;
        } catch (SQLException ex) {
            // hacer uso de Logger
            System.out.println(ex.getMessage());
            throw new OperacionRegistrosException("Ocurrió un error al leer la base de datos, inténtelo de nuevo y si el error persiste comuníquese con el encargado del sistema.");
        }
    }
    private operacionesTablaDTO operacionesTablaDTO(ResultSet resultado) throws SQLException {
        int folio = resultado.getInt("folio");
        String nombres = resultado.getString("nombres");
        String paterno = resultado.getString("apellidoP");
        String materno = resultado.getString("apellidoM");
        String tipo = resultado.getBoolean("tipo") == true ? "transferencia" : "retiro sin cuenta";
        String cantidad = resultado.getString("cantidad");
        String numCuenta = resultado.getString("noDeCuenta_cuenta");
        String numCuentaReceptor = resultado.getString("noDeCuentaReceptor");
        String estado = resultado.getString("estadoDeRetiro");
        
        return new operacionesTablaDTO(folio , nombres, paterno, materno, tipo, cantidad, numCuenta, numCuentaReceptor, estado);
    }
}
