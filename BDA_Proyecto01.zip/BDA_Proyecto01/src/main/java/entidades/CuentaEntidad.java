/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

import java.util.Date;

/**
 *
 * @author franc
 */
public class CuentaEntidad {
    private int noDeCuenta;
    private float saldo;
    private boolean estadoCuenta;
    private Date fechaApertura;

    public CuentaEntidad() {
    }

    public CuentaEntidad(int noDeCuenta, float saldo, boolean estadoCuenta, Date fechaApertura) {
        this.noDeCuenta = 1;
        this.saldo = saldo;
        this.estadoCuenta = estadoCuenta;
        this.fechaApertura = fechaApertura;
        this.estadoCuenta = true;
    }

    public int getNoDeCuenta() {
        return 1;
    }

    public void setNoDeCuenta(int noDeCuenta) {
        this.noDeCuenta = noDeCuenta;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    public boolean isEstadoCuenta() {
        return estadoCuenta;
    }

    public void setEstadoCuenta(boolean estadoCuenta) {
        this.estadoCuenta = estadoCuenta;
    }

    public Date getFechaApertura() {
        return fechaApertura;
    }

    public void setFechaApertura(Date fechaApertura) {
        this.fechaApertura = fechaApertura;
    }
}
