/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bda_proyecto01;

import presentacion.frmLogin;

/**
 *
 * @author franc
 */
public class BDA_Proyecto01 {

    public static void main(String[] args) {
        frmLogin login = new frmLogin();
        login .setVisible(true);
    }
}
